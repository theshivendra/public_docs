#!/bin/bash

# Exit immediately if any command fails
set -e

# 🔧 Function to display status messages
status_message() {
    echo -e "\n🔧 $1\n"
}

# ✅ Check if Python 3.12.3 is installed, if not, install it
status_message "Checking if Python 3.12.3 is installed..."
if ! python3.12 --version 2>/dev/null | grep -q "3.12.3"; then
    status_message "Installing Python 3.12.3..."
    sudo apt update
    sudo apt install -y software-properties-common
    sudo add-apt-repository -y ppa:deadsnakes/ppa
    sudo apt update
    sudo apt install -y python3.12 python3.12-venv
else
    status_message "✅ Python 3.12.3 is already installed."
fi

# ✅ Check if pip for Python 3.12 is installed, if not, install it
status_message "Checking if pip is installed for Python 3.12..."
if ! python3.12 -m pip --version &>/dev/null; then
    status_message "Installing pip for Python 3.12..."
    curl -sS https://bootstrap.pypa.io/get-pip.py -o get-pip.py
    python3.12 get-pip.py --user
    rm get-pip.py
else
    status_message "✅ pip is already installed for Python 3.12."
fi

# ✅ Create and activate the virtual environment
status_message "Creating and activating the virtual environment..."
python3.12 -m venv ~/my_python_env
source ~/my_python_env/bin/activate

# ✅ Ensure pip is up-to-date in the virtual environment
status_message "Upgrading pip in the virtual environment..."
pip install --upgrade pip

# ✅ Installing necessary packages (PyYAML, pylint)
status_message "Installing necessary packages (PyYAML, pylint)..."
pip install PyYAML pylint

# ✅ Running pylint to check pylint score
pylint generator.py

# ✅ Running generator.py with time measurement
status_message "🚀 Running time measurement for generator.py..."
time python3 generator.py

# ✅ Running Unit Tests
status_message "✅ Running Unit Tests..."
python3 tests/test_generator.py

# ✅ Running Functional Tests
status_message "✅ Running Functional Tests..."
python3 tests/functional_test.py

# ✅ Deactivating the virtual environment
status_message "🔌 Deactivating the virtual environment..."
deactivate

status_message "✅ All setup and tests completed successfully!"


