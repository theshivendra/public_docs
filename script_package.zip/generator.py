"""
generator.py

This script extracts unique keys from XML (in the form {{key}}),
matches them with values from a configuration file, and generates a
ConfigMap YAML file.
"""
import os
import re
import xml.etree.ElementTree as ET
import yaml
def extract_keys_from_uri(uri):
    """
    Extract all nested keys of the form {{key}} from the given URI, including nested keys.
    Args:
        uri (str): The URI containing placeholders.
    Returns:
        list: List of extracted unique keys.
    """
    if any(proto.lower() in uri.lower().split(":")[0] for proto in
           ["cxf", "cxfrs", "activemq", "jdbc"]):
        return []
    keys = set()
    pattern = re.compile(r"\{\{([^{}]+(?:\{\{[^{}]*\}\})?[^{}]*)\}\}")
    while True:
        matches = pattern.findall(uri)
        if not matches:
            break
        for match in matches:
            inner_matches = re.findall(r"\{\{([^{}]+)\}\}", match)
            keys.update(inner_matches)  # Add the inner nested keys
            keys.add(match.strip())  # Add the outer match
        uri = pattern.sub("", uri)
    # Extract keys within the nested placeholders and flatten them
    nested_keys = re.findall(r"\{\{([^{}]+(?:\{\{[^{}]*\}\})?[^{}]*)\}\}", uri)
    for nested_key in nested_keys:
        keys.add(nested_key.strip())
    return list(keys)
def remove_xml_comments(raw_xml):
    """Remove XML comments from the given XML string."""
    return re.sub(r'<!--.*?-->', '', raw_xml, flags=re.DOTALL)
def extract_unique_keys_from_xml(xml_path):
    """
    Extract unique keys from an XML file.

    Args:
        xml_path (str): Path to the XML file.

    Returns:
        list: Sorted list of unique keys extracted from the XML.
    """
    with open(xml_path, "r", encoding="utf-8") as f:
        raw_xml = f.read()
    clean_xml = remove_xml_comments(raw_xml)
    root = ET.fromstring(clean_xml)
    unique_keys = set()
    for route in root.findall(".//{*}route"):
        for tag in route.findall(".//{*}from") + route.findall(".//{*}to"):
            uri = tag.attrib.get("uri")
            if uri:
                keys = extract_keys_from_uri(uri)
                unique_keys.update(keys)
    return sorted(unique_keys)
def load_config(config_file):
    """
    Load key-value pairs from a configuration file.

    Args:
        config_file (str): Path to the config file.

    Returns:
        dict: Dictionary of loaded configuration values.
    """
    config = {}
    with open(config_file, 'r', encoding='utf-8') as file:
        for line in file:
            if '=' in line and not line.strip().startswith("#"):
                key, value = line.strip().split('=', 1)
                config[key.strip()] = value.strip()
    return config
def resolve_placeholders(key, config):
    """
    Resolve placeholders in the key using values from the config dictionary.

    Args:
        key (str): The key with placeholders.
        config (dict): Configuration dictionary.

    Returns:
        str: Key with resolved placeholders.
    """
    placeholders = re.findall(r'{{(.*?)}}', key)
    for placeholder in placeholders:
        key = key.replace(f'{{{{{placeholder}}}}}', config.get(placeholder, ""))
    return key
def create_configmap_yaml(config, resolved_keys, output_yaml):
    """
    Generate a ConfigMap YAML with resolved keys.

    Args:
        config (dict): Configuration dictionary.
        resolved_keys (list): List of resolved keys.
        output_yaml (str): Path for the output YAML file.
    """
    configmap = {
        "apiVersion": "v1",
        "kind": "ConfigMap",
        "metadata": {"name": "generated-configmap"},
        "data": {key: config.get(key, "") for key in resolved_keys}
    }
    with open(output_yaml, "w", encoding="utf-8") as file:
        yaml.dump(configmap, file, default_flow_style=False)
    print(f"✅ ConfigMap saved to '{output_yaml}'")
def main():
    """
    Main function to generate a ConfigMap from XML keys and config values.

    It reads keys from an XML file, resolves them using a config file, 
    and generates a ConfigMap YAML file.
    """
    xml_file = "blueprint.xml"
    config_file = "dummy.cfg"
    # count_of_keys_file = "countofkeys.txt"
    resolved_keys_file = "resolved_keys.txt"

    keys = extract_unique_keys_from_xml(xml_file)
    config = load_config(config_file)
    resolved_keys = [resolve_placeholders(key, config) for key in keys]
    with open(resolved_keys_file, "w", encoding="utf-8") as file:
        for key in resolved_keys:
            file.write(f"{key}\n")
    output_yaml = f"configmap-{os.path.splitext(os.path.basename(xml_file))[0]}-" \
                  f"{os.path.splitext(os.path.basename(config_file))[0]}.yaml"
    create_configmap_yaml(config, resolved_keys, output_yaml)
if __name__ == "__main__":
    main()
