#!/bin/bash
set -e  # Exit on any error (except for missing files now handled safely)

PYTHON_VERSION="3.12.3"
INSTALL_DIR="$HOME/python$PYTHON_VERSION"
PYTHON_EXEC="$INSTALL_DIR/bin/python3"

# Logging helper
log() {
  echo -e "\n🔹 $1"
}

# Check if Python 3.12.3 is already installed
if [[ ! -x "$PYTHON_EXEC" ]]; then
    log "Installing Python $PYTHON_VERSION from source..."

    # Install build dependencies
    sudo apt update -qq
    sudo apt install -y -qq wget build-essential libssl-dev zlib1g-dev \
        libncurses5-dev libncursesw5-dev libreadline-dev libsqlite3-dev \
        libgdbm-dev libdb5.3-dev libbz2-dev libexpat1-dev liblzma-dev \
        libffi-dev uuid-dev > /dev/null

    # Download and compile Python
    cd /tmp
    wget -q https://www.python.org/ftp/python/$PYTHON_VERSION/Python-$PYTHON_VERSION.tgz
    tar -xf Python-$PYTHON_VERSION.tgz
    cd Python-$PYTHON_VERSION
    ./configure --prefix=$INSTALL_DIR --enable-optimizations > /dev/null
    make -j$(nproc) > /dev/null
    make install > /dev/null

    log "✅ Python $PYTHON_VERSION installed in $INSTALL_DIR"
else
    log "✅ Python $PYTHON_VERSION is already installed."
fi

# Ensure pip is available
$PYTHON_EXEC -m ensurepip --upgrade > /dev/null

# Create virtual environment
log "Creating virtual environment..."
$PYTHON_EXEC -m venv ~/my_python_env
source ~/my_python_env/bin/activate

# Create the target directory
DEST=~/Desktop/scriptByShivendra
mkdir -p "$DEST"

# Move files only if they exist
log "Moving project files to $DEST..."
for file in generator.py blueprint.xml dummy.cfg tests run_test11.sh; do
    if [[ -e "$file" ]]; then
        mv "$file" "$DEST"
    else
        log "⚠️ Warning: $file not found, skipping."
    fi
done

log "✅ Setup complete. Your files are in $DEST"

