#!/bin/bash

# Exit if any command fails
set -e

# Check if Python 3.12.3 is installed, if not, install it
if ! python3 --version | grep -q "3.12.3"; then
    echo "Installing Python 3.12.3..."
    sudo apt update
    sudo apt install -y software-properties-common
    sudo add-apt-repository ppa:deadsnakes/ppa -y
    sudo apt update
    sudo apt install -y python3.12 python3.12-venv python3.12-distutils
else
    echo "✅ Python 3.12.3 is already installed."
fi

# Check if pip is installed, if not, install it
if ! command -v pip3 &> /dev/null; then
    echo "Installing pip..."
    curl -sS https://bootstrap.pypa.io/get-pip.py -o get-pip.py
    python3.12 get-pip.py --user
    rm get-pip.py
else
    echo "✅ pip is already installed."
fi

# Create and activate the virtual environment
echo "Creating virtual environment..."
python3.12 -m venv ~/my_python_env
source ~/my_python_env/bin/activate

# Create the directory scriptByShivendra
mkdir -p ~/Desktop/scriptByShivendra

# Move all extracted files to scriptByShivendra directory
echo "Moving extracted files to scriptByShivendra..."
mv generator.py blueprint.xml dummy.cfg tests run_test11.sh  ~/Desktop/scriptByShivendra/

# Confirmation message
echo "✅ Setup complete. Your files are in ~/Desktop/scriptByShivendra."


