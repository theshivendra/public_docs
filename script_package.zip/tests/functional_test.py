import unittest
import tempfile
import os
import shutil
import sys

# Add the parent directory to sys.path so we can import generator.py
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from generator import extract_unique_keys_from_xml, load_config, resolve_placeholders, create_configmap_yaml

class TestConfigMapGeneratorFunctional(unittest.TestCase):

    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.xml_file = os.path.join(self.test_dir, "test_blueprint.xml")
        self.cfg_file = os.path.join(self.test_dir, "test_config.cfg")

        with open(self.xml_file, "w", encoding="utf-8") as f:
            f.write("""
                <blueprint>
                    <camelContext xmlns="http://camel.apache.org/schema/blueprint">
                        <route>
                            <from uri="restlet:{{endpoint1}}"/>
                            <to uri="http:{{host}}/api/{{path}}"/>
                        </route>
                    </camelContext>
                </blueprint>
            """)

        with open(self.cfg_file, "w", encoding="utf-8") as f:
            f.write("endpoint1=http://example.com\nhost=localhost\npath=data")

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_full_workflow(self):
        # Extract keys
        keys = extract_unique_keys_from_xml(self.xml_file)

        # Load config
        config = load_config(self.cfg_file)

        # Resolve placeholders
        resolved_keys = [resolve_placeholders(key, config) for key in keys]

        # Generate ConfigMap
        output_yaml = os.path.join(self.test_dir, f"configmap-{os.path.splitext(os.path.basename(self.xml_file))[0]}-test_config.yaml")
        create_configmap_yaml(config, resolved_keys, output_yaml)

        # Check if ConfigMap YAML was generated
        self.assertTrue(os.path.exists(output_yaml))

        with open(output_yaml, "r", encoding="utf-8") as f:
            content = f.read()
            self.assertIn("http://example.com", content)
            self.assertIn("localhost", content)
            self.assertIn("data", content)

if __name__ == "__main__":
    unittest.main(verbosity=2)
