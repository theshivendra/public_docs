# import unittest
# import tempfile
# import os
# import shutil
# import sys

# # Add the parent directory to sys.path so we can import generator.py
# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# from generator import (
#     extract_keys_from_uri,
#     remove_xml_comments,
#     extract_unique_keys_from_xml,
#     load_config,
#     resolve_placeholders,
#     write_resolved_keys_to_file,
#     create_configmap_yaml,
# )

# class TestConfigMapGenerator(unittest.TestCase):

#     def setUp(self):
#         # Create a temporary test directory
#         self.test_dir = tempfile.mkdtemp()

#         # Create sample XML and config files
#         self.xml_file = os.path.join(self.test_dir, "test_blueprint.xml")
#         self.cfg_file = os.path.join(self.test_dir, "test_config.cfg")
#         self.output_yaml = os.path.join(self.test_dir, "configmap-test.yaml")

#         with open(self.xml_file, "w", encoding="utf-8") as f:
#             f.write("""
#                 <blueprint>
#                     <camelContext xmlns="http://camel.apache.org/schema/blueprint">
#                         <route>
#                             <from uri="restlet:{{endpoint1}}"/>
#                             <to uri="http:{{host}}/api/{{path}}"/>
#                         </route>
#                     </camelContext>
#                 </blueprint>
#             """)

#         with open(self.cfg_file, "w", encoding="utf-8") as f:
#             f.write("endpoint1=http://example.com\nhost=localhost\npath=data")

#     def tearDown(self):
#         # Remove temp directory after each test
#         shutil.rmtree(self.test_dir)

#     def test_extract_keys_from_uri(self):
#         uri = "http:{{host}}/api/{{path}}"
#         keys = extract_keys_from_uri(uri)
#         self.assertIn("host", keys)
#         self.assertIn("path", keys)

#     def test_remove_xml_comments(self):
#         raw = "<!-- Comment --><tag>value</tag>"
#         cleaned = remove_xml_comments(raw)
#         self.assertNotIn("<!--", cleaned)

#     def test_extract_unique_keys_from_xml(self):
#         keys = extract_unique_keys_from_xml(self.xml_file)
#         self.assertIn("endpoint1", keys)
#         self.assertIn("host", keys)
#         self.assertIn("path", keys)

#     def test_load_config(self):
#         config = load_config(self.cfg_file)
#         self.assertEqual(config["endpoint1"], "http://example.com")
#         self.assertEqual(config["host"], "localhost")
#         self.assertEqual(config["path"], "data")

#     def test_resolve_placeholders(self):
#         config = {"host": "localhost", "path": "data"}
#         key = "{{host}}/api/{{path}}"
#         resolved = resolve_placeholders(key, config)
#         self.assertEqual(resolved, "localhost/api/data")

#     def test_read_keys_from_file(self):
#         # Write keys to a temporary file
#         keys_file = os.path.join(self.test_dir, "keys.txt")
#         with open(keys_file, "w", encoding="utf-8") as f:
#             f.write("key1\nkey2\n")
#         keys = read_keys_from_file(keys_file)
#         self.assertEqual(keys, ["key1", "key2"])

#     def test_write_resolved_keys_to_file(self):
#         resolved_keys_file = os.path.join(self.test_dir, "resolved_keys.txt")
#         keys = ["resolved1", "resolved2"]
#         write_resolved_keys_to_file(resolved_keys_file, keys)

#         with open(resolved_keys_file, "r", encoding="utf-8") as f:
#             lines = f.read().splitlines()
#         self.assertEqual(lines, keys)

#     def test_create_configmap_yaml(self):
#         config = load_config(self.cfg_file)
#         resolved_keys = ["endpoint1", "host", "path"]
#         create_configmap_yaml(config, resolved_keys, self.output_yaml)

#         # Check file created
#         self.assertTrue(os.path.exists(self.output_yaml))

#         # Check expected content in YAML
#         with open(self.output_yaml, "r", encoding="utf-8") as f:
#             content = f.read()
#             self.assertIn("endpoint1", content)
#             self.assertIn("http://example.com", content)
#             self.assertIn("localhost", content)
#             self.assertIn("data", content)

# # Run the tests
# if __name__ == "__main__":
#     unittest.main(verbosity=2)



import unittest
import tempfile
import os
import shutil
import sys

# Add the parent directory to sys.path so we can import generator.py
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from generator import (
    extract_keys_from_uri,
    remove_xml_comments,
    extract_unique_keys_from_xml,
    load_config,
    resolve_placeholders,
    create_configmap_yaml,
)

class TestConfigMapGenerator(unittest.TestCase):

    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.xml_file = os.path.join(self.test_dir, "test_blueprint.xml")
        self.cfg_file = os.path.join(self.test_dir, "test_config.cfg")
        self.output_yaml = os.path.join(self.test_dir, "configmap-test.yaml")

        with open(self.xml_file, "w", encoding="utf-8") as f:
            f.write("""
                <blueprint>
                    <camelContext xmlns="http://camel.apache.org/schema/blueprint">
                        <route>
                            <from uri="restlet:{{endpoint1}}"/>
                            <to uri="http:{{host}}/api/{{path}}"/>
                        </route>
                    </camelContext>
                </blueprint>
            """)

        with open(self.cfg_file, "w", encoding="utf-8") as f:
            f.write("endpoint1=http://example.com\nhost=localhost\npath=data")

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_extract_keys_from_uri(self):
        uri = "http:key1{{key2}}/api/{{key3}}"
        keys = extract_keys_from_uri(uri)
        self.assertCountEqual(keys, ["key2", "key3"])

    def test_extract_keys_from_uri_with_nested_keys(self):
        uri = "http:{{outer{{inner}}}}/api/{{path}}"
        keys = extract_keys_from_uri(uri)
        self.assertCountEqual(keys, ["outer{{inner}}", "inner", "path"])

    def test_remove_xml_comments(self):
        raw = "<!-- Comment --><tag>value</tag>"
        self.assertEqual(remove_xml_comments(raw), "<tag>value</tag>")

    def test_extract_unique_keys_from_xml(self):
        keys = extract_unique_keys_from_xml(self.xml_file)
        self.assertEqual(sorted(keys), ["endpoint1", "host", "path"])

    def test_load_config(self):
        config = load_config(self.cfg_file)
        self.assertEqual(config["endpoint1"], "http://example.com")

    def test_resolve_placeholders(self):
        config = {"host": "localhost", "path": "data"}
        self.assertEqual(resolve_placeholders("{{host}}/api/{{path}}", config), "localhost/api/data")

    def test_create_configmap_yaml(self):
        config = load_config(self.cfg_file)
        resolved_keys = ["endpoint1", "host", "path"]
        create_configmap_yaml(config, resolved_keys, self.output_yaml)

        self.assertTrue(os.path.exists(self.output_yaml))

        with open(self.output_yaml, "r", encoding="utf-8") as f:
            content = f.read()
            self.assertIn("http://example.com", content)
            self.assertIn("localhost", content)
            self.assertIn("data", content)

if __name__ == "__main__":
    unittest.main(verbosity=2)
